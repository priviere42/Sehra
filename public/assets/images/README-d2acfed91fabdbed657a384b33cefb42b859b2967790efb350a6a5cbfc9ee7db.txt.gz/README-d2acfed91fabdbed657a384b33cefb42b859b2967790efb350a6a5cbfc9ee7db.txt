This folder contain demo files.
You can delete it!